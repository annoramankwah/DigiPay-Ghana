import hashlib, os, secrets, uuid, requests
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, abort, flash, jsonify, redirect, render_template, request, url_for
from flask_login import LoginManager, current_user, login_required, login_user, logout_user
from flask_jwt_extended import JWTManager, create_access_token, create_refresh_token, jwt_required, get_jwt_identity
from dotenv import load_dotenv
from werkzeug.security import check_password_hash, generate_password_hash
from models import db, User, Student, Invoice, Payment, Receipt, LedgerEntry, DeveloperApp, ApiKey, Institution
load_dotenv()
app=Flask(__name__)
app.config['SECRET_KEY']=os.getenv('SECRET_KEY','development-secret-change-me')
app.config['SQLALCHEMY_DATABASE_URI']=os.getenv('DATABASE_URL','sqlite:///digipay.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.config['JWT_SECRET_KEY']=os.getenv('JWT_SECRET_KEY',os.getenv('SECRET_KEY','development-secret-change-me'))
app.config['JWT_ACCESS_TOKEN_EXPIRES']=timedelta(hours=1)
app.config['JWT_REFRESH_TOKEN_EXPIRES']=timedelta(days=30)
PAYSTACK_SECRET_KEY=os.getenv('PAYSTACK_SECRET_KEY','')
PAYSTACK_PUBLIC_KEY=os.getenv('PAYSTACK_PUBLIC_KEY','')
PAYSTACK_API_URL='https://api.paystack.co'
USE_PAYSTACK=bool(PAYSTACK_SECRET_KEY)
db.init_app(app)
jwt=JWTManager(app)
lm=LoginManager(app); lm.login_view='login'
@lm.user_loader
def load_user(uid): return db.session.get(User,int(uid))
@app.before_request
def enforce_https_headers():
 response={}
 if not request.is_secure and not app.debug:
  return redirect(request.url.replace('http://','https://'),code=301)
@app.after_request
def set_security_headers(response):
 response.headers['X-Content-Type-Options']='nosniff'
 response.headers['X-Frame-Options']='DENY'
 response.headers['X-XSS-Protection']='1; mode=block'
 response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
 response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'"
 return response
def role_required(*roles):
 def outer(fn):
  @wraps(fn)
  @login_required
  def inner(*a,**k):
   if current_user.role not in roles: abort(403)
   return fn(*a,**k)
  return inner
 return outer
@app.template_filter('money')
def money(v): return f'{(v or 0)/100:,.2f}'
@app.get('/')
def home(): return redirect(url_for('dashboard')) if current_user.is_authenticated else render_template('home.html')
@app.route('/login',methods=['GET','POST'])
def login():
 if current_user.is_authenticated:return redirect(url_for('dashboard'))
 if request.method=='POST':
  u=User.query.filter_by(email=request.form['email'].strip().lower()).first()
  if u and check_password_hash(u.password_hash,request.form['password']): login_user(u); return redirect(url_for('dashboard'))
  flash('Invalid email or password.','danger')
 return render_template('login.html')
@app.route('/signup',methods=['GET','POST'])
def signup():
 if current_user.is_authenticated:return redirect(url_for('dashboard'))
 if request.method=='POST':
  email=request.form['email'].strip().lower()
  name=request.form['name'].strip()
  password=request.form['password']
  confirm_password=request.form['confirm_password']
  student_number=request.form.get('student_number','').strip()
  if not all([email,name,password,confirm_password]): flash('All fields are required.','danger'); return render_template('signup.html')
  if password!=confirm_password: flash('Passwords do not match.','danger'); return render_template('signup.html')
  if len(password)<8: flash('Password must be at least 8 characters.','danger'); return render_template('signup.html')
  if User.query.filter_by(email=email).first(): flash('Email already registered.','danger'); return render_template('signup.html')
  inst=Institution.query.filter_by(slug='digipay-demo').first()
  if not inst: flash('Institution not configured.','danger'); return render_template('signup.html')
  pw_hash=generate_password_hash(password)
  user=User(institution_id=inst.id,name=name,email=email,password_hash=pw_hash,role='student')
  db.session.add(user); db.session.flush()
  student=Student(institution_id=inst.id,user_id=user.id,student_number=student_number or f'STU-{user.id}',full_name=name)
  db.session.add(student); db.session.commit()
  login_user(user); flash('Account created successfully!','success'); return redirect(url_for('dashboard'))
 return render_template('signup.html')
@app.get('/logout')
@login_required
def logout(): logout_user(); return redirect(url_for('home'))
@app.post('/api/v1/auth/token')
def api_token():
 data=request.get_json() or {}
 email=data.get('email','').strip().lower()
 password=data.get('password','')
 if not email or not password:return jsonify({'error':'Email and password required'}),400
 user=User.query.filter_by(email=email).first()
 if not user or not check_password_hash(user.password_hash,password):return jsonify({'error':'Invalid credentials'}),401
 access_token=create_access_token(identity=str(user.id))
 refresh_token=create_refresh_token(identity=str(user.id))
 return jsonify({'access_token':access_token,'refresh_token':refresh_token,'token_type':'Bearer'}),200
@app.post('/api/v1/auth/refresh')
@jwt_required(refresh=True)
def api_refresh():
 user_id=get_jwt_identity()
 access_token=create_access_token(identity=user_id)
 return jsonify({'access_token':access_token,'token_type':'Bearer'}),200
@app.get('/dashboard')
@login_required
def dashboard():
 iid=current_user.institution_id
 if current_user.role=='student':
  student=Student.query.filter_by(user_id=current_user.id,institution_id=iid).first_or_404(); inv=Invoice.query.filter_by(student_id=student.id).order_by(Invoice.created_at.desc()).all(); payments=Payment.query.filter_by(institution_id=iid,status='succeeded').all(); return render_template('student_dashboard.html',student=student,invoices=inv,payments=payments)
 if current_user.role=='developer': return redirect(url_for('developer'))
 inv=Invoice.query.filter_by(institution_id=iid).all(); payments=Payment.query.filter_by(institution_id=iid,status='succeeded').all(); return render_template('admin_dashboard.html',student_count=Student.query.filter_by(institution_id=iid).count(),invoices=inv,payments=payments)
@app.route('/students',methods=['GET','POST'])
@role_required('admin')
def students():
 if request.method=='POST':
  db.session.add(Student(institution_id=current_user.institution_id,student_number=request.form['student_number'],full_name=request.form['full_name'],programme=request.form['programme'],level=request.form['level'])); db.session.commit(); flash('Student created.','success'); return redirect(url_for('students'))
 return render_template('students.html',students=Student.query.filter_by(institution_id=current_user.institution_id).all())
@app.route('/invoices',methods=['GET','POST'])
@login_required
def invoices():
 iid=current_user.institution_id
 if request.method=='POST':
  if current_user.role!='admin': abort(403)
  amount=int(round(float(request.form['amount'])*100)); db.session.add(Invoice(institution_id=iid,student_id=int(request.form['student_id']),number='INV-'+datetime.utcnow().strftime('%Y%m%d%H%M%S%f'),description=request.form['description'],amount_minor=amount,due_date=datetime.strptime(request.form['due_date'],'%Y-%m-%d').date())); db.session.commit(); flash('Invoice created.','success'); return redirect(url_for('invoices'))
 q=Invoice.query.filter_by(institution_id=iid)
 if current_user.role=='student': q=q.filter_by(student_id=Student.query.filter_by(user_id=current_user.id).first_or_404().id)
 return render_template('invoices.html',invoices=q.order_by(Invoice.created_at.desc()).all(),students=Student.query.filter_by(institution_id=iid).all())
@app.post('/payments/start/<int:invoice_id>')
@login_required
def start_payment(invoice_id):
 inv=Invoice.query.filter_by(id=invoice_id,institution_id=current_user.institution_id).first_or_404()
 if current_user.role=='student' and inv.student_id!=Student.query.filter_by(user_id=current_user.id).first_or_404().id: abort(403)
 key=request.form.get('idempotency_key') or uuid.uuid4().hex
 existing=Payment.query.filter_by(institution_id=current_user.institution_id,idempotency_key=key).first()
 if existing:return redirect(url_for('checkout',reference=existing.reference))
 amount=int(round(float(request.form.get('amount') or inv.outstanding_minor/100)*100))
 if amount<1 or amount>inv.outstanding_minor: abort(400)
 payment=Payment(institution_id=current_user.institution_id,invoice_id=inv.id,reference='DGP-'+uuid.uuid4().hex.upper(),amount_minor=amount,channel=request.form.get('channel','mobile_money'),idempotency_key=key); db.session.add(payment); db.session.commit(); return redirect(url_for('checkout',reference=payment.reference))
@app.route('/checkout/<reference>',methods=['GET','POST'])
@login_required
def checkout(reference):
 payment=Payment.query.filter_by(reference=reference,institution_id=current_user.institution_id).first_or_404()
 if request.method=='POST' and payment.status=='pending':
  if USE_PAYSTACK:return redirect(url_for('paystack_initialize',payment_id=payment.id))
  else:
   inv=payment.invoice; payment.status='succeeded'; payment.provider_reference='MOCK-'+uuid.uuid4().hex[:16].upper(); payment.completed_at=datetime.utcnow(); inv.paid_minor=min(inv.amount_minor,inv.paid_minor+payment.amount_minor); inv.status='paid' if inv.paid_minor==inv.amount_minor else 'partially_paid'; receipt=Receipt(payment=payment,number='RCT-'+uuid.uuid4().hex[:14].upper()); db.session.add_all([receipt,LedgerEntry(payment_id=payment.id,account='PSP_CLEARING',side='debit',amount_minor=payment.amount_minor),LedgerEntry(payment_id=payment.id,account='STUDENT_RECEIVABLE',side='credit',amount_minor=payment.amount_minor)]); db.session.commit(); return redirect(url_for('receipt',payment_id=payment.id))
 return render_template('checkout.html',payment=payment,paystack_key=PAYSTACK_PUBLIC_KEY,use_paystack=USE_PAYSTACK)
@app.route('/paystack/initialize/<int:payment_id>')
@login_required
def paystack_initialize(payment_id):
 payment=Payment.query.get_or_404(payment_id)
 if payment.institution_id!=current_user.institution_id:abort(403)
 if not USE_PAYSTACK:abort(400)
 amount_ghs=payment.amount_minor/100
 headers={'Authorization':f'Bearer {PAYSTACK_SECRET_KEY}','Content-Type':'application/json'}
 data={'email':current_user.email,'amount':int(payment.amount_minor),'reference':payment.reference,'metadata':{'payment_id':payment.id,'student_id':payment.invoice.student_id,'institution_id':payment.institution_id}}
 try:
  response=requests.post(f'{PAYSTACK_API_URL}/transaction/initialize',json=data,headers=headers,timeout=10)
  if response.status_code==200:
   result=response.json()
   if result.get('status'):return redirect(result['data']['authorization_url'])
  flash('Payment initialization failed. Please try again.','danger')
 except Exception as e:
  flash(f'Error: {str(e)}','danger')
 return redirect(url_for('checkout',reference=payment.reference))
@app.route('/paystack/callback')
@login_required
def paystack_callback():
 reference=request.args.get('reference')
 if not reference:abort(400)
 payment=Payment.query.filter_by(reference=reference,institution_id=current_user.institution_id).first_or_404()
 if not USE_PAYSTACK:abort(400)
 headers={'Authorization':f'Bearer {PAYSTACK_SECRET_KEY}'}
 try:
  response=requests.get(f'{PAYSTACK_API_URL}/transaction/verify/{reference}',headers=headers,timeout=10)
  if response.status_code==200:
   result=response.json()
   if result.get('status') and result['data'].get('status')=='success':
    if payment.status=='pending':
     payment.status='succeeded';payment.provider_reference=result['data'].get('reference');payment.completed_at=datetime.utcnow()
     inv=payment.invoice;inv.paid_minor=min(inv.amount_minor,inv.paid_minor+payment.amount_minor);inv.status='paid'if inv.paid_minor==inv.amount_minor else'partially_paid'
     receipt=Receipt(payment=payment,number='RCT-'+uuid.uuid4().hex[:14].upper())
     db.session.add_all([receipt,LedgerEntry(payment_id=payment.id,account='PSP_CLEARING',side='debit',amount_minor=payment.amount_minor),LedgerEntry(payment_id=payment.id,account='STUDENT_RECEIVABLE',side='credit',amount_minor=payment.amount_minor)])
     db.session.commit();flash('Payment successful!','success');return redirect(url_for('receipt',payment_id=payment.id))
    return redirect(url_for('receipt',payment_id=payment.id))
 except Exception as e:
  flash(f'Verification error: {str(e)}','danger')
 return redirect(url_for('checkout',reference=payment.reference))
@app.get('/receipt/<int:payment_id>')
@login_required
def receipt(payment_id): return render_template('receipt.html',payment=Payment.query.filter_by(id=payment_id,institution_id=current_user.institution_id,status='succeeded').first_or_404())
@app.route('/developer',methods=['GET','POST'])
@role_required('developer','admin')
def developer():
 if request.method=='POST': db.session.add(DeveloperApp(institution_id=current_user.institution_id,owner_id=current_user.id,name=request.form['name'])); db.session.commit(); flash('Application created.','success'); return redirect(url_for('developer'))
 return render_template('developer.html',apps=DeveloperApp.query.filter_by(institution_id=current_user.institution_id).all())
@app.post('/developer/key/<int:app_id>')
@role_required('developer','admin')
def create_key(app_id):
 dev=DeveloperApp.query.filter_by(id=app_id,institution_id=current_user.institution_id).first_or_404(); raw='dgp_test_'+secrets.token_hex(24); db.session.add(ApiKey(app_id=dev.id,prefix=raw[:18],key_hash=hashlib.sha256(raw.encode()).hexdigest())); db.session.commit(); flash('Copy this API key now: '+raw,'key'); return redirect(url_for('developer'))
@app.get('/api/v1/invoices')
@jwt_required()
def api_invoices():
 user_id=get_jwt_identity()
 user=User.query.get_or_404(user_id)
 return jsonify([{'id':x.id,'number':x.number,'amount_minor':x.amount_minor,'paid_minor':x.paid_minor,'status':x.status} for x in Invoice.query.filter_by(institution_id=user.institution_id).all()])
if __name__=='__main__':
 with app.app_context(): db.create_all()
 app.run(debug=os.getenv('FLASK_DEBUG')=='1')
@app.template_filter('money')
def money(v): return f'{(v or 0)/100:,.2f}'
@app.get('/')
def home(): return redirect(url_for('dashboard')) if current_user.is_authenticated else render_template('home.html')
@app.route('/login',methods=['GET','POST'])
def login():
 if current_user.is_authenticated:return redirect(url_for('dashboard'))
 if request.method=='POST':
  u=User.query.filter_by(email=request.form['email'].strip().lower()).first()
  if u and check_password_hash(u.password_hash,request.form['password']): login_user(u); return redirect(url_for('dashboard'))
  flash('Invalid email or password.','danger')
 return render_template('login.html')
@app.route('/signup',methods=['GET','POST'])
def signup():
 if current_user.is_authenticated:return redirect(url_for('dashboard'))
 if request.method=='POST':
  email=request.form['email'].strip().lower()
  name=request.form['name'].strip()
  password=request.form['password']
  confirm_password=request.form['confirm_password']
  student_number=request.form.get('student_number','').strip()
  if not all([email,name,password,confirm_password]): flash('All fields are required.','danger'); return render_template('signup.html')
  if password!=confirm_password: flash('Passwords do not match.','danger'); return render_template('signup.html')
  if len(password)<8: flash('Password must be at least 8 characters.','danger'); return render_template('signup.html')
  if User.query.filter_by(email=email).first(): flash('Email already registered.','danger'); return render_template('signup.html')
  inst=Institution.query.filter_by(slug='digipay-demo').first()
  if not inst: flash('Institution not configured.','danger'); return render_template('signup.html')
  pw_hash=generate_password_hash(password)
  user=User(institution_id=inst.id,name=name,email=email,password_hash=pw_hash,role='student')
  db.session.add(user); db.session.flush()
  student=Student(institution_id=inst.id,user_id=user.id,student_number=student_number or f'STU-{user.id}',full_name=name)
  db.session.add(student); db.session.commit()
  login_user(user); flash('Account created successfully!','success'); return redirect(url_for('dashboard'))
 return render_template('signup.html')
@app.get('/logout')
@login_required
def logout(): logout_user(); return redirect(url_for('home'))
@app.get('/dashboard')
@login_required
def dashboard():
 iid=current_user.institution_id
 if current_user.role=='student':
  student=Student.query.filter_by(user_id=current_user.id,institution_id=iid).first_or_404(); inv=Invoice.query.filter_by(student_id=student.id).order_by(Invoice.created_at.desc()).all(); payments=Payment.query.filter_by(institution_id=iid,status='succeeded').all(); return render_template('student_dashboard.html',student=student,invoices=inv,payments=payments)
 if current_user.role=='developer': return redirect(url_for('developer'))
 inv=Invoice.query.filter_by(institution_id=iid).all(); payments=Payment.query.filter_by(institution_id=iid,status='succeeded').all(); return render_template('admin_dashboard.html',student_count=Student.query.filter_by(institution_id=iid).count(),invoices=inv,payments=payments)
@app.route('/students',methods=['GET','POST'])
@role_required('admin')
def students():
 if request.method=='POST':
  db.session.add(Student(institution_id=current_user.institution_id,student_number=request.form['student_number'],full_name=request.form['full_name'],programme=request.form['programme'],level=request.form['level'])); db.session.commit(); flash('Student created.','success'); return redirect(url_for('students'))
 return render_template('students.html',students=Student.query.filter_by(institution_id=current_user.institution_id).all())
@app.route('/invoices',methods=['GET','POST'])
@login_required
def invoices():
 iid=current_user.institution_id
 if request.method=='POST':
  if current_user.role!='admin': abort(403)
  amount=int(round(float(request.form['amount'])*100)); db.session.add(Invoice(institution_id=iid,student_id=int(request.form['student_id']),number='INV-'+datetime.utcnow().strftime('%Y%m%d%H%M%S%f'),description=request.form['description'],amount_minor=amount,due_date=datetime.strptime(request.form['due_date'],'%Y-%m-%d').date())); db.session.commit(); flash('Invoice created.','success'); return redirect(url_for('invoices'))
 q=Invoice.query.filter_by(institution_id=iid)
 if current_user.role=='student': q=q.filter_by(student_id=Student.query.filter_by(user_id=current_user.id).first_or_404().id)
 return render_template('invoices.html',invoices=q.order_by(Invoice.created_at.desc()).all(),students=Student.query.filter_by(institution_id=iid).all())
@app.post('/payments/start/<int:invoice_id>')
@login_required
def start_payment(invoice_id):
 inv=Invoice.query.filter_by(id=invoice_id,institution_id=current_user.institution_id).first_or_404()
 if current_user.role=='student' and inv.student_id!=Student.query.filter_by(user_id=current_user.id).first_or_404().id: abort(403)
 key=request.form.get('idempotency_key') or uuid.uuid4().hex
 existing=Payment.query.filter_by(institution_id=current_user.institution_id,idempotency_key=key).first()
 if existing:return redirect(url_for('checkout',reference=existing.reference))
 amount=int(round(float(request.form.get('amount') or inv.outstanding_minor/100)*100))
 if amount<1 or amount>inv.outstanding_minor: abort(400)
 payment=Payment(institution_id=current_user.institution_id,invoice_id=inv.id,reference='DGP-'+uuid.uuid4().hex.upper(),amount_minor=amount,channel=request.form.get('channel','mobile_money'),idempotency_key=key); db.session.add(payment); db.session.commit(); return redirect(url_for('checkout',reference=payment.reference))
@app.route('/checkout/<reference>',methods=['GET','POST'])
@login_required
def checkout(reference):
 payment=Payment.query.filter_by(reference=reference,institution_id=current_user.institution_id).first_or_404()
 if request.method=='POST' and payment.status=='pending':
  if USE_PAYSTACK:return redirect(url_for('paystack_initialize',payment_id=payment.id))
  else:
   inv=payment.invoice; payment.status='succeeded'; payment.provider_reference='MOCK-'+uuid.uuid4().hex[:16].upper(); payment.completed_at=datetime.utcnow(); inv.paid_minor=min(inv.amount_minor,inv.paid_minor+payment.amount_minor); inv.status='paid' if inv.paid_minor==inv.amount_minor else 'partially_paid'; receipt=Receipt(payment=payment,number='RCT-'+uuid.uuid4().hex[:14].upper()); db.session.add_all([receipt,LedgerEntry(payment_id=payment.id,account='PSP_CLEARING',side='debit',amount_minor=payment.amount_minor),LedgerEntry(payment_id=payment.id,account='STUDENT_RECEIVABLE',side='credit',amount_minor=payment.amount_minor)]); db.session.commit(); return redirect(url_for('receipt',payment_id=payment.id))
 return render_template('checkout.html',payment=payment,paystack_key=PAYSTACK_PUBLIC_KEY,use_paystack=USE_PAYSTACK)
@app.route('/paystack/initialize/<int:payment_id>')
@login_required
def paystack_initialize(payment_id):
 payment=Payment.query.get_or_404(payment_id)
 if payment.institution_id!=current_user.institution_id:abort(403)
 if not USE_PAYSTACK:abort(400)
 amount_ghs=payment.amount_minor/100
 headers={'Authorization':f'Bearer {PAYSTACK_SECRET_KEY}','Content-Type':'application/json'}
 data={'email':current_user.email,'amount':int(payment.amount_minor),'reference':payment.reference,'metadata':{'payment_id':payment.id,'student_id':payment.invoice.student_id,'institution_id':payment.institution_id}}
 try:
  response=requests.post(f'{PAYSTACK_API_URL}/transaction/initialize',json=data,headers=headers,timeout=10)
  if response.status_code==200:
   result=response.json()
   if result.get('status'):return redirect(result['data']['authorization_url'])
  flash('Payment initialization failed. Please try again.','danger')
 except Exception as e:
  flash(f'Error: {str(e)}','danger')
 return redirect(url_for('checkout',reference=payment.reference))
@app.route('/paystack/callback')
@login_required
def paystack_callback():
 reference=request.args.get('reference')
 if not reference:abort(400)
 payment=Payment.query.filter_by(reference=reference,institution_id=current_user.institution_id).first_or_404()
 if not USE_PAYSTACK:abort(400)
 headers={'Authorization':f'Bearer {PAYSTACK_SECRET_KEY}'}
 try:
  response=requests.get(f'{PAYSTACK_API_URL}/transaction/verify/{reference}',headers=headers,timeout=10)
  if response.status_code==200:
   result=response.json()
   if result.get('status') and result['data'].get('status')=='success':
    if payment.status=='pending':
     payment.status='succeeded';payment.provider_reference=result['data'].get('reference');payment.completed_at=datetime.utcnow()
     inv=payment.invoice;inv.paid_minor=min(inv.amount_minor,inv.paid_minor+payment.amount_minor);inv.status='paid'if inv.paid_minor==inv.amount_minor else'partially_paid'
     receipt=Receipt(payment=payment,number='RCT-'+uuid.uuid4().hex[:14].upper())
     db.session.add_all([receipt,LedgerEntry(payment_id=payment.id,account='PSP_CLEARING',side='debit',amount_minor=payment.amount_minor),LedgerEntry(payment_id=payment.id,account='STUDENT_RECEIVABLE',side='credit',amount_minor=payment.amount_minor)])
     db.session.commit();flash('Payment successful!','success');return redirect(url_for('receipt',payment_id=payment.id))
    return redirect(url_for('receipt',payment_id=payment.id))
 except Exception as e:
  flash(f'Verification error: {str(e)}','danger')
 return redirect(url_for('checkout',reference=payment.reference))
@app.get('/receipt/<int:payment_id>')
@login_required
def receipt(payment_id): return render_template('receipt.html',payment=Payment.query.filter_by(id=payment_id,institution_id=current_user.institution_id,status='succeeded').first_or_404())
@app.route('/developer',methods=['GET','POST'])
@role_required('developer','admin')
def developer():
 if request.method=='POST': db.session.add(DeveloperApp(institution_id=current_user.institution_id,owner_id=current_user.id,name=request.form['name'])); db.session.commit(); flash('Application created.','success'); return redirect(url_for('developer'))
 return render_template('developer.html',apps=DeveloperApp.query.filter_by(institution_id=current_user.institution_id).all())
@app.post('/developer/key/<int:app_id>')
@role_required('developer','admin')
def create_key(app_id):
 dev=DeveloperApp.query.filter_by(id=app_id,institution_id=current_user.institution_id).first_or_404(); raw='dgp_test_'+secrets.token_hex(24); db.session.add(ApiKey(app_id=dev.id,prefix=raw[:18],key_hash=hashlib.sha256(raw.encode()).hexdigest())); db.session.commit(); flash('Copy this API key now: '+raw,'key'); return redirect(url_for('developer'))
@app.get('/api/v1/invoices')
@login_required
def api_invoices(): return jsonify([{'id':x.id,'number':x.number,'amount_minor':x.amount_minor,'paid_minor':x.paid_minor,'status':x.status} for x in Invoice.query.filter_by(institution_id=current_user.institution_id).all()])
if __name__=='__main__':
 with app.app_context(): db.create_all()
 app.run(debug=os.getenv('FLASK_DEBUG')=='1')
