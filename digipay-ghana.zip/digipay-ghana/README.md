# Digipay - Secure University Payment Platform

**A professional educational payment system built with Python Flask and modern web technologies.**

Enterprise-grade payment processing for educational institutions with industry-standard security, responsive design, and seamless integration.

## Key Features

### 1. **Secure Payment Processing**
-  AES-256 encryption for all transactions
-  PCI-DSS compliant payment gateway (Paystack)
-  Automatic payment verification & confirmation
-  Real-time transaction status tracking
-  Double-entry ledger accounting

### 2. **Professional User Interface**
-  Enterprise-grade design patterns
-  Fully responsive (mobile, tablet, desktop)
-  Intuitive navigation and workflows
-  Accessibility compliant (WCAG 2.1)
-  Fast loading times & smooth interactions

### 3. **Institutional Integration**
-  Multi-institution support
-  Customizable institutional dashboards
-  Automated invoice management
-  Real-time payment reconciliation
-  Comprehensive audit trails

### 4. **Robust Security**
-  JWT authentication with token-based API access
-  SSL/TLS encryption for all connections
-  Security headers (HSTS, CSP, X-Frame-Options)
-  Role-based access control (RBAC)
-  Data encryption at rest and in transit
-  Secure password hashing (bcrypt)
-  CSRF protection & input validation
-  SQL injection prevention (SQLAlchemy ORM)

---

## Quick Start

### Prerequisites
- Python 3.8+
- pip (Python package manager)

### Installation

#### Windows PowerShell
```powershell
cd digipay

py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt

Copy-Item .env.example .env
python seed.py
python app.py
```

#### macOS / Linux
```bash
cd digipay

python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
python seed.py
python app.py
```

### Access Application
Open your browser: **http://127.0.0.1:5000**

---

## User Roles

| Role | Access Level | Capabilities |
|------|--------------|--------------|
| **Student** | Standard | View invoices, make payments, download receipts |
| **Admin** | Full | Manage students, create invoices, view reports |
| **Developer** | API | Create applications, manage API keys |

---

## Payment Methods

### Mock Payment (Development)
- No real card required
- Instant confirmation
- Perfect for testing

### Paystack Payments (Production)
- Real payment processing in Ghana
- All major payment channels supported
- Secure & PCI-DSS compliant

#### Configure Paystack
1. Create account: https://dashboard.paystack.com
2. Get API keys from dashboard
3. Add to `.env`:
   ```
   PAYSTACK_SECRET_KEY=sk_live_xxxxx
   PAYSTACK_PUBLIC_KEY=pk_live_xxxxx
   ```

---

## Project Structure

```
digipay/
├── app.py                 # Main Flask application
├── models.py             # Database models
├── requirements.txt      # Dependencies
├── .env.example          # Environment template
├── schema.sql            # Database schema
├── templates/            # HTML templates (11 files)
│   ├── login.html
│   ├── signup.html
│   ├── checkout.html
│   └── ...
└── static/
    ├── css/style.css    # Responsive styles
    └── js/app.js        # Client logic
```

---

##  Security Features

### Authentication
- Secure password hashing (Werkzeug)
- Session management (Flask-Login)
- CSRF protection
- Role-based access control

### Payments
- No card data stored locally
- Paystack PCI-DSS compliance
- Idempotent processing
- Webhook verification

### Data
- SQLAlchemy ORM (SQL injection prevention)
- Input validation & sanitization
- Double-entry accounting
- Audit trails

---

##  Responsive Design

### Desktop (1024px+)
- 4-column grids
- Full sidebar navigation
- Optimized spacing

### Tablet (800-1024px)
- 2-column layouts
- Mobile menu support
- Responsive tables

### Mobile (<800px)
- Single column
- Hamburger navigation
- Touch-optimized buttons

---

##  API Endpoints

### Authentication (New JWT API)
```
POST   /api/v1/auth/token        # Get access & refresh tokens
POST   /api/v1/auth/refresh      # Refresh expired access token
```

### Resource APIs
```
GET    /api/v1/invoices          # List invoices (requires JWT)
```

### Web Routes
```
POST   /login              # User authentication
POST   /signup             # Student registration
GET    /logout             # End session
GET    /dashboard          # Role-specific dashboard
GET    /invoices           # View invoices
POST   /invoices           # Create invoice (admin)
POST   /payments/start/<id> # Initiate payment
GET    /checkout/<ref>     # Payment checkout
GET    /receipt/<id>       # Payment receipt
```

For detailed API documentation, see [API.md](./API.md)

---

## Security & JWT Authentication

### New Security Features
- **JWT Token-Based API** - Stateless authentication with access/refresh tokens
- **SSL/TLS Encryption** - Self-signed certificates in `/certificates/`
- **Security Headers** - HSTS, CSP, X-Frame-Options, XSS Protection
- **Token Expiration** - Access tokens: 1 hour, Refresh tokens: 30 days
- **Institution Isolation** - Users only access their institution's data

### Getting JWT Tokens
```bash
POST /api/v1/auth/token
{
  "email": "user@test.edu",
  "password": "SecurePassword123!"
}
```

### Using Tokens in API Calls
```bash
GET /api/v1/invoices
Authorization: Bearer <access_token>
```

For comprehensive security information and best practices, see [SECURITY.md](./SECURITY.md)

---

##  Database

### Tables
- **user** - Authentication & profiles
- **student** - Student records
- **invoice** - Fee invoices
- **payment** - Payment transactions
- **receipt** - Payment receipts
- **ledger_entry** - Accounting entries

---

## Testing

### Payment Flow
1. Sign up for account
2. Navigate to Invoices
3. Click "Pay Invoice"
4. Complete payment
5. View receipt

### Responsive Testing
- Desktop: Full width browser
- Tablet: 768px width
- Mobile: 390px width

---

## Security Checklist

Before production:
- [ ] Change SECRET_KEY to secure random value
- [ ] Set FLASK_DEBUG=0
- [ ] Configure Paystack production credentials
- [ ] Enable HTTPS/SSL
- [ ] Configure database backups
- [ ] Review all environment variables
- [ ] Test payment workflow end-to-end

---

## 📈 Performance Optimization

- Efficient database queries
- CSS Grid/Flexbox layouts
- Lazy asset loading
- Minified static files
- Optimized images

---

## 📞 Support

- **Paystack Docs**: https://paystack.com/docs
- **Flask Docs**: https://flask.palletsprojects.com
- **SQLAlchemy**: https://docs.sqlalchemy.org

---

## 📄 License

Commercial use - Contact for details.

---

**Status**: Production-Ready ✅  
**Version**: 2.0.0  
**Last Updated**: 2026-09-01
