# Digipay API Reference

## Authentication

All API endpoints require JWT (JSON Web Token) authentication.

### Getting Started with JWT

#### 1. Obtain Token
```bash
curl -X POST http://127.0.0.1:5000/api/v1/auth/token \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@test.edu",
    "password": "SecurePassword123!"
  }'
```

Response:
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "token_type": "Bearer"
}
```

#### 2. Use Token in Requests
```bash
curl -X GET http://127.0.0.1:5000/api/v1/invoices \
  -H "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
```

#### 3. Refresh Token (When Access Token Expires)
```bash
curl -X POST http://127.0.0.1:5000/api/v1/auth/refresh \
  -H "Authorization: Bearer <refresh_token>"
```

Response:
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "token_type": "Bearer"
}
```

---

## API Endpoints

### Authentication Endpoints

#### POST /api/v1/auth/token
Obtain access and refresh tokens using email and password.

**Request:**
```json
{
  "email": "user@test.edu",
  "password": "SecurePassword123!"
}
```

**Response (200 OK):**
```json
{
  "access_token": "string",
  "refresh_token": "string",
  "token_type": "Bearer"
}
```

**Error (401 Unauthorized):**
```json
{
  "error": "Invalid credentials"
}
```

---

#### POST /api/v1/auth/refresh
Refresh expired access token using refresh token.

**Headers:**
```
Authorization: Bearer <refresh_token>
```

**Response (200 OK):**
```json
{
  "access_token": "string",
  "token_type": "Bearer"
}
```

**Error (401 Unauthorized):**
```json
{
  "msg": "Token has expired"
}
```

---

### Invoice Endpoints

#### GET /api/v1/invoices
Get all invoices for the authenticated user's institution.

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response (200 OK):**
```json
[
  {
    "id": 1,
    "number": "INV-2024-0001",
    "amount_minor": 320000,
    "paid_minor": 0,
    "status": "pending"
  },
  {
    "id": 2,
    "number": "INV-2024-0002",
    "amount_minor": 12000,
    "paid_minor": 12000,
    "status": "paid"
  }
]
```

**Error (401 Unauthorized):**
```json
{
  "msg": "Missing Authorization Header"
}
```

---

## Integration Examples

### Python
```python
import requests

# Get token
response = requests.post('http://127.0.0.1:5000/api/v1/auth/token', json={
    'email': 'user@test.edu',
    'password': 'SecurePassword123!'
})
token = response.json()['access_token']

# Use token to fetch invoices
headers = {'Authorization': f'Bearer {token}'}
invoices = requests.get('http://127.0.0.1:5000/api/v1/invoices', headers=headers)
print(invoices.json())
```

### JavaScript/Node.js
```javascript
// Get token
const tokenResponse = await fetch('http://127.0.0.1:5000/api/v1/auth/token', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'user@test.edu',
    password: 'SecurePassword123!'
  })
});

const { access_token } = await tokenResponse.json();

// Use token to fetch invoices
const invoicesResponse = await fetch('http://127.0.0.1:5000/api/v1/invoices', {
  headers: { 'Authorization': `Bearer ${access_token}` }
});

const invoices = await invoicesResponse.json();
console.log(invoices);
```

### cURL
```bash
# Get token
TOKEN=$(curl -s -X POST http://127.0.0.1:5000/api/v1/auth/token \
  -H "Content-Type: application/json" \
  -d '{"email":"user@test.edu","password":"SecurePassword123!"}' \
  | jq -r '.access_token')

# Fetch invoices
curl -X GET http://127.0.0.1:5000/api/v1/invoices \
  -H "Authorization: Bearer $TOKEN"
```

---

## Error Responses

### 400 Bad Request
```json
{
  "error": "Invalid request parameters"
}
```

### 401 Unauthorized
```json
{
  "msg": "Missing Authorization Header"
}
```

### 403 Forbidden
```json
{
  "msg": "User does not have permission"
}
```

### 404 Not Found
```json
{
  "error": "Resource not found"
}
```

### 500 Server Error
```json
{
  "error": "Internal server error"
}
```

---

## Rate Limiting

Currently no rate limiting is implemented. For production, implement:
- 100 requests per minute per user
- 10 requests per second per IP address
- Exponential backoff for failed authentication attempts

---

## Pagination

Pagination coming soon. For now, all results are returned without pagination.

---

## Versioning

- Current API version: v1
- Backward compatible changes will be included in v1
- Breaking changes will be released in v2

---

## Support

For API support or issues:
1. Check the [SECURITY.md](./SECURITY.md) for security best practices
2. Review [README.md](./README.md) for system documentation
3. Check server logs for detailed error messages

---

**Last Updated**: 2026-09-01
**API Version**: v1.0
