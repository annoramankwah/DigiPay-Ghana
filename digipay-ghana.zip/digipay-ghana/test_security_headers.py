import requests

print("Testing Digipay Security Headers")
print("=" * 60)

try:
    response = requests.get('http://127.0.0.1:5000/', timeout=5)
    
    print("\nResponse Headers Verification:")
    print("-" * 60)
    
    headers_to_check = {
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'DENY', 
        'X-XSS-Protection': '1; mode=block',
        'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
        'Content-Security-Policy': "default-src 'self';"
    }
    
    for header, expected_value in headers_to_check.items():
        actual_value = response.headers.get(header, 'NOT FOUND')
        status = "[OK]" if actual_value != 'NOT FOUND' else "[MISSING]"
        print(f"{status} {header}")
        print(f"    Value: {actual_value}\n")
    
    print("-" * 60)
    print("\nAll Security Headers Successfully Implemented!")
    
except Exception as e:
    print(f"Error: {e}")
