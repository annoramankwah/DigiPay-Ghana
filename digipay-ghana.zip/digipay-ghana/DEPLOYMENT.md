# Deployment & Production Guide

## Production Standards Implemented

### ✅ Responsive Design
- **Mobile-First Approach**: Base styles optimized for mobile
- **Flexible Layouts**: CSS Grid and Flexbox for responsive grids
- **Fluid Typography**: Font sizes scale with viewport (clamp)
- **Touch-Friendly**: Larger buttons and inputs for mobile
- **Breakpoints**:
  - `> 1024px` - Desktop (4-col layouts)
  - `800px - 1024px` - Tablet (2-col layouts)
  - `500px - 800px` - Mobile (1-col, responsive typography)
  - `< 500px` - Small mobile (touch optimized)

### ✅ Real Payment API Integration
- **Paystack Integration**: Live payment processing
- **Fallback Mock Mode**: Development/testing without credentials
- **Secure Webhooks**: Callback verification for payments
- **Idempotent Processing**: Duplicate payment prevention
- **Error Handling**: Comprehensive error messages

### ✅ Professional Standards
- **Security**: CSRF protection, password hashing, SQL injection prevention
- **Validation**: Server-side form validation with user feedback
- **Accessibility**: Semantic HTML, ARIA labels, keyboard navigation
- **Performance**: Optimized CSS, lazy loading, efficient queries
- **Documentation**: Inline comments, clear code structure
- **Testing**: Manual test flows included

---

## Paystack Setup for Production

### 1. Create Paystack Account
```
1. Visit https://dashboard.paystack.com
2. Sign up with your email
3. Complete verification process
4. Activate your account
```

### 2. Get API Keys
```
Dashboard → Settings → API Keys & Webhooks
- Copy Secret Key (sk_live_xxx)
- Copy Public Key (pk_live_xxx)
```

### 3. Configure .env File
```bash
PAYSTACK_SECRET_KEY=sk_live_xxxxxxxxxxxxx
PAYSTACK_PUBLIC_KEY=pk_live_xxxxxxxxxxxxx
```

### 4. Test Payment Flow
1. Login as student
2. Navigate to invoices
3. Click pay invoice
4. You'll be redirected to Paystack
5. Use Paystack test cards:
   - **Success**: 4084084084084081
   - **Decline**: 5018717012345678
   - Exp: Any future date
   - CVV: Any 3 digits

### 5. Webhook Configuration
```
Dashboard → Settings → Webhooks
URL: https://yourdomain.com/paystack/callback
Events: Successful payment
```

---

## Deployment Options

### Option A: Local Development
```bash
python app.py
# Access: http://127.0.0.1:5000
```

### Option B: Production with Gunicorn
```bash
# Install Gunicorn
pip install gunicorn

# Run with 4 workers
gunicorn -w 4 -b 0.0.0.0:8000 app:app

# Or with systemd service
sudo nano /etc/systemd/system/digipay.service
```

Example systemd service:
```ini
[Unit]
Description=Digipay Ghana Payment System
After=network.target

[Service]
User=www-data
WorkingDirectory=/var/www/digipay-ghana
ExecStart=/var/www/digipay-ghana/.venv/bin/gunicorn -w 4 -b 127.0.0.1:8000 app:app
Restart=always

[Install]
WantedBy=multi-user.target
```

### Option C: Docker Deployment
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:8000", "app:app"]
```

### Option D: Cloud Platforms

#### Heroku
```bash
heroku create digipay-ghana
heroku config:set SECRET_KEY=your-secret-key
heroku config:set PAYSTACK_SECRET_KEY=sk_live_xxx
heroku config:set PAYSTACK_PUBLIC_KEY=pk_live_xxx
git push heroku main
```

#### PythonAnywhere
1. Upload code to PythonAnywhere
2. Create virtual environment
3. Configure web app settings
4. Point to WSGI file
5. Add environment variables

---

## Security Checklist

### Before Production
- [ ] Change `SECRET_KEY` to cryptographically secure value
- [ ] Set `FLASK_DEBUG=0`
- [ ] Configure Paystack production keys
- [ ] Enable HTTPS/SSL certificate
- [ ] Use production database (PostgreSQL recommended)
- [ ] Configure database backups
- [ ] Set up error logging/monitoring
- [ ] Review all secret variables
- [ ] Test payment workflow end-to-end
- [ ] Load test the application

### HTTPS Setup
```bash
# Using Let's Encrypt & Certbot
sudo certbot certonly --standalone -d yourdomain.com

# Update Nginx/Apache config to use certificates
# Redirect HTTP to HTTPS
```

### Environment Variables
```bash
# Production .env
SECRET_KEY=generate-with-secrets.token_hex(32)
DATABASE_URL=postgresql://user:pass@localhost/digipay
FLASK_DEBUG=0
PAYSTACK_SECRET_KEY=sk_live_xxxxxxxxxxxxx
PAYSTACK_PUBLIC_KEY=pk_live_xxxxxxxxxxxxx
```

---

## Database Management

### Development
```bash
# SQLite (default)
DATABASE_URL=sqlite:///digipay.db
```

### Production
```bash
# PostgreSQL recommended
DATABASE_URL=postgresql://user:password@localhost:5432/digipay_db
pip install psycopg2-binary
```

### Migrations
```bash
# Using Flask-Migrate (optional)
pip install Flask-Migrate
flask db init
flask db migrate -m "Description"
flask db upgrade
```

### Backup
```bash
# SQLite backup
cp digipay.db digipay.db.backup

# PostgreSQL backup
pg_dump digipay_db > backup.sql
```

---

## Monitoring & Logging

### Application Logging
```python
import logging
logging.basicConfig(filename='digipay.log', level=logging.INFO)
```

### Monitor Payment Status
```bash
# Check payment transactions
curl -H "Authorization: Bearer sk_live_xxx" \
  https://api.paystack.co/transaction/list
```

### Error Tracking
- Sentry (recommended): https://sentry.io
- Rollbar: https://rollbar.com
- CloudFlare Logs

---

## Performance Optimization

### Caching
```python
from flask_caching import Cache
cache = Cache(app, config={'CACHE_TYPE': 'simple'})

@app.route('/invoices')
@cache.cached(timeout=300)
def invoices():
    ...
```

### Database Optimization
```python
# Use eager loading
invoices = Invoice.query.options(
    db.joinedload(Invoice.student)
).all()

# Index frequently queried columns
class Invoice(db.Model):
    __table_args__ = (
        db.Index('idx_institution_student', 'institution_id', 'student_id'),
    )
```

### Static File Optimization
```bash
# Compress CSS/JS
pip install django-compressor

# Use CDN for static files
# Update STATIC_URL to point to CDN
```

---

## Troubleshooting

### Common Issues

#### Payment not processing
```
1. Check Paystack credentials are correct
2. Verify webhook is enabled
3. Check firewall allows outbound HTTPS
4. Review logs for API errors
```

#### Database errors
```
1. Check database connection string
2. Verify database exists and accessible
3. Run seed.py to initialize schema
4. Check user permissions
```

#### Performance issues
```
1. Enable caching for database queries
2. Use pagination for large datasets
3. Optimize database indexes
4. Use production WSGI server
5. Enable gzip compression
```

---

## Maintenance

### Regular Tasks
- Weekly: Check application logs
- Weekly: Verify payment processing
- Monthly: Database maintenance & backups
- Monthly: Security updates
- Quarterly: Performance review

### Monitoring Commands
```bash
# Check service status
sudo systemctl status digipay

# View logs
tail -f digipay.log

# Check Paystack sync
python -c "from app import app; print(app.config['PAYSTACK_SECRET_KEY'])"
```

---

## Final Checklist for Submission

- [ ] Responsive design tested on desktop, tablet, mobile
- [ ] Payment API integrated and tested
- [ ] All user roles working (admin, student, developer)
- [ ] Form validation and error messages working
- [ ] Database relationships correct
- [ ] Security features implemented
- [ ] Code commented and documented
- [ ] README.md complete
- [ ] Demo accounts provided
- [ ] No hardcoded secrets in code
- [ ] All dependencies in requirements.txt
- [ ] Application deployed and accessible
- [ ] Error handling covers edge cases

---

## Support

**Paystack Support**: support@paystack.com  
**Flask Documentation**: https://flask.palletsprojects.com  
**Stack Overflow**: Tag `[flask]` `[paystack]`

---

**Status**: Production Ready ✅  
**Last Updated**: 2026-09-01  
**Version**: 1.0.0
