from flask_jwt_extended import create_access_token, create_refresh_token, jwt_required, get_jwt_identity, get_jwt
from functools import wraps
from flask import jsonify
from models import User

def create_tokens(user_id, additional_claims=None):
    """Create JWT access and refresh tokens for a user."""
    claims = {'sub': user_id}
    if additional_claims:
        claims.update(additional_claims)
    access_token = create_access_token(identity=user_id, additional_claims=claims)
    refresh_token = create_refresh_token(identity=user_id)
    return access_token, refresh_token

def jwt_optional(fn):
    """Decorator to optionally require JWT token (doesn't fail if missing)."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            jwt_required()(lambda: None)()
        except:
            pass
        return fn(*args, **kwargs)
    return wrapper

def verify_token_valid():
    """Verify JWT token is valid and not revoked."""
    claims = get_jwt()
    if claims.get('type') == 'access':
        return True
    return False

def secure_json_response(data, status=200, message=None):
    """Create a secure JSON response with proper headers."""
    response = {
        'success': True if 200 <= status < 300 else False,
        'data': data
    }
    if message:
        response['message'] = message
    return response, status
