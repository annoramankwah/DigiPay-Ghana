from datetime import datetime
from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy

db=SQLAlchemy()
class Institution(db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(150),nullable=False); slug=db.Column(db.String(80),unique=True,nullable=False); currency=db.Column(db.String(3),default='GHS')
class User(UserMixin,db.Model):
 id=db.Column(db.Integer,primary_key=True); institution_id=db.Column(db.Integer,db.ForeignKey('institution.id'),nullable=False); name=db.Column(db.String(120),nullable=False); email=db.Column(db.String(180),unique=True,nullable=False); password_hash=db.Column(db.String(255),nullable=False); role=db.Column(db.String(20),nullable=False)
class Student(db.Model):
 __table_args__=(db.UniqueConstraint('institution_id','student_number'),)
 id=db.Column(db.Integer,primary_key=True); institution_id=db.Column(db.Integer,db.ForeignKey('institution.id'),nullable=False); user_id=db.Column(db.Integer,db.ForeignKey('user.id'),unique=True); student_number=db.Column(db.String(40),nullable=False); full_name=db.Column(db.String(150),nullable=False); programme=db.Column(db.String(120)); level=db.Column(db.String(40)); invoices=db.relationship('Invoice',backref='student',lazy=True)
class Invoice(db.Model):
 __table_args__=(db.UniqueConstraint('institution_id','number'),)
 id=db.Column(db.Integer,primary_key=True); institution_id=db.Column(db.Integer,db.ForeignKey('institution.id'),nullable=False); student_id=db.Column(db.Integer,db.ForeignKey('student.id'),nullable=False); number=db.Column(db.String(60),nullable=False); description=db.Column(db.String(200),nullable=False); amount_minor=db.Column(db.Integer,nullable=False); paid_minor=db.Column(db.Integer,default=0); status=db.Column(db.String(30),default='pending'); due_date=db.Column(db.Date,nullable=False); created_at=db.Column(db.DateTime,default=datetime.utcnow)
 @property
 def outstanding_minor(self): return max(0,self.amount_minor-self.paid_minor)
class Payment(db.Model):
 __table_args__=(db.UniqueConstraint('institution_id','idempotency_key'),)
 id=db.Column(db.Integer,primary_key=True); institution_id=db.Column(db.Integer,nullable=False); invoice_id=db.Column(db.Integer,db.ForeignKey('invoice.id'),nullable=False); reference=db.Column(db.String(90),unique=True,nullable=False); provider_reference=db.Column(db.String(90),unique=True); amount_minor=db.Column(db.Integer,nullable=False); channel=db.Column(db.String(40),nullable=False); status=db.Column(db.String(30),default='pending'); idempotency_key=db.Column(db.String(90),nullable=False); completed_at=db.Column(db.DateTime); invoice=db.relationship('Invoice'); receipt=db.relationship('Receipt',backref='payment',uselist=False)
class Receipt(db.Model):
 id=db.Column(db.Integer,primary_key=True); payment_id=db.Column(db.Integer,db.ForeignKey('payment.id'),unique=True,nullable=False); number=db.Column(db.String(80),unique=True,nullable=False); issued_at=db.Column(db.DateTime,default=datetime.utcnow)
class LedgerEntry(db.Model):
 id=db.Column(db.Integer,primary_key=True); payment_id=db.Column(db.Integer,db.ForeignKey('payment.id'),nullable=False); account=db.Column(db.String(80),nullable=False); side=db.Column(db.String(10),nullable=False); amount_minor=db.Column(db.Integer,nullable=False)
class DeveloperApp(db.Model):
 id=db.Column(db.Integer,primary_key=True); institution_id=db.Column(db.Integer,nullable=False); owner_id=db.Column(db.Integer,nullable=False); name=db.Column(db.String(120),nullable=False); created_at=db.Column(db.DateTime,default=datetime.utcnow); keys=db.relationship('ApiKey',backref='app')
class ApiKey(db.Model):
 id=db.Column(db.Integer,primary_key=True); app_id=db.Column(db.Integer,db.ForeignKey('developer_app.id'),nullable=False); prefix=db.Column(db.String(20),nullable=False); key_hash=db.Column(db.String(64),nullable=False); created_at=db.Column(db.DateTime,default=datetime.utcnow)
