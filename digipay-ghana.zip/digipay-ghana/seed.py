from datetime import date
from werkzeug.security import generate_password_hash
from app import app
from models import db, Institution, User, Student, Invoice, Payment, Receipt, LedgerEntry
with app.app_context():
 db.drop_all(); db.create_all(); inst=Institution(name='Ghana Educational Consortium',slug='digipay-demo'); db.session.add(inst); db.session.flush(); pw=generate_password_hash('SecurePassword123!')
 admin=User(institution_id=inst.id,name='Administrator',email='admin@institution.edu',password_hash=pw,role='admin'); su=User(institution_id=inst.id,name='Test User',email='user@test.edu',password_hash=pw,role='student'); dev=User(institution_id=inst.id,name='Developer',email='dev@institution.edu',password_hash=pw,role='developer'); db.session.add_all([admin,su,dev]); db.session.flush()
 student=Student(institution_id=inst.id,user_id=su.id,student_number='STU-2024-0001',full_name='Test User',programme='Computer Science',level='Level 300'); db.session.add(student); db.session.flush()
 rows=[('Tuition Fee - Semester 2',320000,'paid'),('Library Fee',12000,'paid'),('Examination Fee',45000,'paid'),('Sports & Welfare',8000,'pending')]
 for n,(desc,amount,status) in enumerate(rows,1):
  inv=Invoice(institution_id=inst.id,student_id=student.id,number=f'INV-2024-{n:04d}',description=desc,amount_minor=amount,paid_minor=amount if status=='paid' else 0,status=status,due_date=date(2026,9,30)); db.session.add(inv); db.session.flush()
  if status=='paid':
   pay=Payment(institution_id=inst.id,invoice_id=inv.id,reference='PAY-'+str(n).zfill(8),provider_reference='GW-'+str(n).zfill(8),amount_minor=amount,channel='mobile_money',status='succeeded',idempotency_key='txn-'+str(n),completed_at=__import__('datetime').datetime.utcnow()); db.session.add(pay); db.session.flush(); db.session.add_all([Receipt(payment_id=pay.id,number='RCP-'+str(n).zfill(8)),LedgerEntry(payment_id=pay.id,account='PSP_CLEARING',side='debit',amount_minor=amount),LedgerEntry(payment_id=pay.id,account='STUDENT_RECEIVABLE',side='credit',amount_minor=amount)])
 db.session.commit(); print('Database initialized successfully')
